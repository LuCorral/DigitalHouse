package com.DigitalHouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoIntegrador1LuciaCorralApplicationTests {



}
