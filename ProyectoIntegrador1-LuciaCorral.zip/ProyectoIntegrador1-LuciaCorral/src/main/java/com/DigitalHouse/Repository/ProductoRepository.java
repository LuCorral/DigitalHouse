package com.DigitalHouse.Repository;

import com.DigitalHouse.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Product, Long> {
}
