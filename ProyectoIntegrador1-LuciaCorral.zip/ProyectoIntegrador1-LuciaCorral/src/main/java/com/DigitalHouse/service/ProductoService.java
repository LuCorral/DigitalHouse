package com.DigitalHouse.service;

import com.DigitalHouse.Repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductoService {
    @Autowired
    public ProductoRepository productoRepository;

}
