package com.DigitalHouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoIntegrador1LuciaCorralApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoIntegrador1LuciaCorralApplication.class, args);
	}

}
